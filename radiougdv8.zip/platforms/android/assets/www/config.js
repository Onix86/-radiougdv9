var stream = {
	hiFi: 'http://70.38.73.27:8005/live',
    loFi: 'http://70.38.73.27:8005/live'
};

var API_URL = " ";
